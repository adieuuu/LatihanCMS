export const removeAllWhiteSpaces = (str) => {
    return str.toString().replace(/\s/g,'')
}